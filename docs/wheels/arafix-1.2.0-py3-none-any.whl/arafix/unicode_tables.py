"""
جداول اليونيكود العربية — تُولَّد اشتقاقاً من `unicodedata` لا يدوياً.

الفلسفة هنا مقصودة: كل جدول في هذا الملف مبنيّ من قاعدة بيانات
اليونيكود المرفقة ببايثون، لا مكتوباً بخط اليد. الفائدة:

  * لا أخطاء مطبعية في ٦٠٠+ نقطة كود.
  * يتحدّث الجدول تلقائياً مع تحديث نسخة يونيكود في بايثون.
  * الاستثناءات وحدها مكتوبة يدوياً، وهي قليلة ومُبرَّرة سطراً سطراً.

المصطلحات:
  Presentation Form : الشكل الرسومي «المطبوخ» للحرف (U+FB50–FEFF).
  Base / Nominal    : الحرف الأصلي في الكتلة العربية (U+0600–06FF).
  Joining form      : ISOLATED / INITIAL / MEDIAL / FINAL.
"""

from __future__ import annotations

import sys
import unicodedata
from collections.abc import Iterable
from enum import Enum

__all__ = [
    "JoiningForm",
    "ARABIC_RANGES",
    "PRESENTATION_RANGES",
    "PUA_RANGES",
    "TATWEEL",
    "ZWJ",
    "ZWNJ",
    "PF_TO_BASE",
    "PF_JOINING_FORM",
    "SIMPLE_PF_TO_BASE",
    "LIGATURE_PF_TO_BASE",
    "SPACING_MARK_PF_TO_BASE",
    "DEFERRED_PF_TO_BASE",
    "ALEF_FORMS",
    "LAM",
    "FINAL_ONLY_LETTERS",
    "is_arabic",
    "is_presentation_form",
    "is_pua",
    "is_arabic_diacritic",
    "in_ranges",
    "unicode_version",
]


# ---------------------------------------------------------------------------
# نطاقات
# ---------------------------------------------------------------------------

#: الكتل العربية الأساسية (الحروف الاسمية المنطقية).
ARABIC_RANGES: tuple[tuple[int, int], ...] = (
    (0x0600, 0x06FF),  # Arabic
    (0x0750, 0x077F),  # Arabic Supplement
    (0x08A0, 0x08FF),  # Arabic Extended-A
)

#: كتل الأشكال الرسومية — هنا يقع أصل الداء.
PRESENTATION_RANGES: tuple[tuple[int, int], ...] = (
    (0xFB50, 0xFDFF),  # Arabic Presentation Forms-A
    (0xFE70, 0xFEFF),  # Arabic Presentation Forms-B
)

#: مناطق الاستعمال الخاص — ظهورها يعني CMap تالف أو خط بترميز خاص.
PUA_RANGES: tuple[tuple[int, int], ...] = (
    (0xE000, 0xF8FF),  # BMP Private Use Area
    (0xF0000, 0xFFFFD),  # Supplementary PUA-A
    (0x100000, 0x10FFFD),  # Supplementary PUA-B
)

TATWEEL = "\u0640"  # ـ  الكشيدة: زخرفة بصرية بلا معنى دلالي
ZWJ = "\u200d"
ZWNJ = "\u200c"

#: حروف لا تقع إلا في آخر الكلمة — أقوى إشارة على الترتيب المنطقي.
FINAL_ONLY_LETTERS = frozenset("ةى")

#: صور الألف كلها. تجاورُ اثنتين منها **مستحيلٌ إملائياً** في العربية،
#: وهذا الاستحالة بعينها هي ما يكشف انقلاب رباط لام-ألف لاحقاً.
ALEF_FORMS = frozenset("اأإآٱ")

LAM = "\u0644"


def in_ranges(cp: int, ranges: Iterable[tuple[int, int]]) -> bool:
    """
    هل نقطة الكود `cp` واقعة في أحد النطاقات المعطاة؟ — التنفيذ المرجعيّ.

    حلقةٌ صريحة لا `any(genexpr)`: المولّد يبني إطاراً لكل نداء، وهذه
    الدالة تُنادى مرّةً لكل محرف.
    """
    for lo, hi in ranges:  # noqa: SIM110 — الحلقة مقصودة، انظر الشرح أعلاه
        if lo <= cp <= hi:
            return True
    return False


def _cps(ranges: Iterable[tuple[int, int]]) -> frozenset:
    return frozenset(cp for lo, hi in ranges for cp in range(lo, hi + 1))


# ---------------------------------------------------------------------------
# مجموعاتٌ مبنيّةٌ مسبقاً للفحوص الساخنة
# ---------------------------------------------------------------------------
#
# `is_arabic` و`is_presentation_form` تُناديان مرّةً لكل محرف في كل مسح،
# وفحصُ العضوية في مجموعةٍ عمليةٌ واحدة بينما مسحُ النطاقات حلقة. قِسناه
# على صفحةٍ واقعية: **١٫٢٤ ms ← ٠٫٢٢ ms، أي ٥٫٥×**.
#
# والمجموعتان مبنيّتان من **النطاقات نفسها** لا مكتوبتين، فلا انحرافَ
# ممكن. ويحرسُ ذلك اختبارٌ يقارن المسار السريع بالمرجعيّ على **كل** نقطة
# كودٍ في المستوى الأساس — لا على عيّنة.
#
# ولا مجموعةَ لـ PUA عمداً: نطاقاتها ١٣٧ ألف نقطة (٥ ميغابايت في الذاكرة)
# مقابل ١٢٣٢ نقطةً للعربية والأشكال. ثمنٌ لا يشتري شيئاً، وهي ثلاثة
# نطاقاتٍ يمسحها المرجعيّ في ثلاث مقارنات.

_ARABIC_CPS = _cps(ARABIC_RANGES)
# U+FEFF (BOM/ZWNBSP) يقع في نطاق أشكال العرض صدفةً تاريخية، والمكتبة
# تحذفه صراحةً من جداول التطبيع أدناه؛ نستبعده من المجموعة السريعة كذلك
# وإلا عدّه is_presentation_form شكلَ رسوميٍّ عربياً وأبلغت diagnose عيباً
# زائفاً عن نصٍّ ليس إلا BOM مكرراً.
_PRESENTATION_CPS = _cps(PRESENTATION_RANGES) - {0xFEFF}


def is_arabic(ch: str) -> bool:
    """حرف عربي اسمي (لا شكل رسومي)."""
    return ord(ch) in _ARABIC_CPS


def is_presentation_form(ch: str) -> bool:
    """شكل رسومي «مطبوخ» يحتاج تطبيعاً."""
    return ord(ch) in _PRESENTATION_CPS


def is_pua(ch: str) -> bool:
    """محرف في منطقة الاستعمال الخاص — لا معنى قياسياً له."""
    return in_ranges(ord(ch), PUA_RANGES)


def is_arabic_diacritic(ch: str) -> bool:
    """تشكيل أو علامة تُركَّب فوق/تحت الحرف (فئة Mn)."""
    return unicodedata.category(ch) == "Mn" and is_arabic(ch)


# ---------------------------------------------------------------------------
# بناء خريطة: شكل رسومي  →  (حرف أساسي، صيغة الوصل)
# ---------------------------------------------------------------------------

class JoiningForm(str, Enum):
    """صيغة وصل الحرف كما تصرّح بها قاعدة يونيكود."""

    ISOLATED = "isolated"
    INITIAL = "initial"
    MEDIAL = "medial"
    FINAL = "final"
    UNKNOWN = "unknown"


_TAG_TO_FORM = {
    "<isolated>": JoiningForm.ISOLATED,
    "<initial>": JoiningForm.INITIAL,
    "<medial>": JoiningForm.MEDIAL,
    "<final>": JoiningForm.FINAL,
}


def _build_pf_tables() -> tuple[dict[str, str], dict[str, JoiningForm]]:
    """
    يبني الجدولين من تفكيك التوافق (compatibility decomposition).

    كل شكل رسومي في يونيكود يحمل تفكيكاً على هيئة:
        U+FEDF  ARABIC LETTER LAM INITIAL FORM  →  <initial> 0644

    فنستخرج منه أمرين معاً في مرور واحد:
        1. الحرف/الحروف الأصلية  (لِمَ الجمع؟ لأن لام-ألف تُفكّ إلى حرفين)
        2. وسم الصيغة  (<initial> …)

    ملاحظة مقصودة: نحتفظ بالتفكيك سلسلةً لا حرفاً واحداً، وهذا ما
    يجعل U+FEF5 (لآ) يعود حرفين صحيحين بدل حرف واحد مشوّه.
    """
    to_base: dict[str, str] = {}
    to_form: dict[str, JoiningForm] = {}

    for lo, hi in PRESENTATION_RANGES:
        for cp in range(lo, hi + 1):
            ch = chr(cp)
            decomp = unicodedata.decomposition(ch)
            if not decomp:
                continue  # نقاط غير مُسنَدة، أو محارف تحكّم كـ U+FEFF
            parts = decomp.split()
            tag = parts[0] if parts[0].startswith("<") else None
            hex_parts = parts[1:] if tag else parts
            if not hex_parts:
                continue
            to_base[ch] = "".join(chr(int(h, 16)) for h in hex_parts)
            to_form[ch] = _TAG_TO_FORM.get(tag or "", JoiningForm.UNKNOWN)

    # --- استثناءات مقصودة -------------------------------------------------
    # U+FEFF هو ZERO WIDTH NO-BREAK SPACE (BOM) لا شكلٌ عربي؛ يقع في النطاق
    # صدفةً تاريخية. نحذفه صراحةً كي لا يُعامَل معاملة الحروف.
    to_base.pop("\ufeff", None)
    to_form.pop("\ufeff", None)

    # U+FE70..FE7F أشكال التشكيل:
    #   * medial: تفكيكها «كشيدة + تشكيل» → نطرح الكشيدة.
    #   * isolated: تفكيكها «مسافة + تشكيل» (U+0020 + Mn) → نطرح المسافة.
    #     بدون هذا يخرج expand « نُ» بمسافة زائدة، فيكسر «نُشرت» و«المتغيّر»
    #     على منصّات تستخرج الأشكال المعزولة (وُثِّق على macOS CI).
    for ch, base in list(to_base.items()):
        if len(base) > 1 and base[0] in (TATWEEL, " ", "\u00a0"):
            to_base[ch] = base[1:]

    # --- الصيغ الشرعية: توسيعٌ موثَّق فقط، وإلا فالتحفظ -------------------
    # دستور المكتبة: لا يُصلَح إلا ما يمكن تبريره. جدول التفكيك العام في
    # يونيكود يحوي مدخلاتٍ لصيغٍ شرعيةٍ صحيحة، وأخرى ينتج منها عربياً
    # فاسداً («صلے» من U+FDF0). فنثبّت الصحيحة يدوياً، ونُسقط الفاسدة
    # كي تبقى محارفها كما هي — التحفُّظ أمانٌ لا قصور.
    _HONORIFIC_VERIFIED = {
        "\ufdfa": "صلى الله عليه وسلم",  # ﷺ
        "\ufdf2": "الله",                # ﷲ
        "\ufdfb": "جل جلاله",            # ﷻ
    }
    for ch, expansion in _HONORIFIC_VERIFIED.items():
        to_base[ch] = expansion

    for bad in ("\ufdf0", "\ufdf1"):
        to_base.pop(bad, None)   # «صلے»/«قلى» — تفكيكٌ غير عربي سليم
        to_form.pop(bad, None)

    return to_base, to_form


PF_TO_BASE, PF_JOINING_FORM = _build_pf_tables()


# ---------------------------------------------------------------------------
# القسمة الحاسمة: ما يُطبَّع الآن  ضدّ  ما يُؤجَّل إلى ما بعد الاتجاه
# ---------------------------------------------------------------------------
#
# هذه القسمة ليست ترتيباً تنظيمياً، بل **شرط سلامة**.
#
# المعيار واحد: **أيُغيّر التطبيعُ بنيةَ العنقود؟** فإن غيّرها، وجب
# تأجيله حتى يستقرّ الترتيب، وإلا عكسَ إصلاحُ الاتجاه ما فكّكناه بأيدينا.
# ويقع تحت هذا المعيار صنفان، وقد كلّفنا كلٌّ منهما عطباً حقيقياً:
#
#   ١) الرباطات (تفكيكٌ إلى أكثر من حرف).
#      «ﻻ» جليفٌ واحد، والرباط في العربية إلزاميّ لا اختياريّ::
#
#          المجلات → ﺍﻟﻤﺠﻼﺕ → [تفكيك] → تلاجملا → [عكس] → المجالت
#
#   ٢) أشكال التشكيل الفاصلة (U+FE70–FE7F).
#      «U+FE79 ضمّةٌ بشكلٍ فاصل» فئتها Lo لا Mn — أي أنها **محرفٌ قائم
#      بذاته** يشغل موضعاً. وتطبيعُها يحيلها علامةً لاصقة (Mn)، فتنقلب
#      وحدةُ العكس من محرفٍ إلى جزءِ عنقود::
#
#          نُشرت → [تطبيع مبكر] → تلتصق بجارها → [عكس] → نشُرت
#
# ومعيار «طول التفكيك» وحده يُعمي عن الصنف الثاني: تفكيك U+FE79 هو
# [كشيدة + ضمّة]، ونحن نطرح الكشيدة أعلاه فيعود الطول واحداً فيبدو
# بريئاً. فالمعيار الصحيح **تغيُّرُ الفئة** لا الطول.


def _changes_cluster_structure(pf: str, base: str) -> bool:
    """أيُغيّر تطبيعُ هذا الشكل بنيةَ العنقود؟ فيجب تأجيله إن غيّرها."""
    if len(base) > 1:
        return True  # رباط: محرفٌ يصير محرفين
    return (
        unicodedata.category(base) == "Mn"
        and unicodedata.category(pf) != "Mn"
    )  # فاصلٌ يصير لاصقاً


SIMPLE_PF_TO_BASE = {
    k: v for k, v in PF_TO_BASE.items() if not _changes_cluster_structure(k, v)
}
DEFERRED_PF_TO_BASE = {
    k: v for k, v in PF_TO_BASE.items() if _changes_cluster_structure(k, v)
}

#: الصنفان تحت المظلّة، مفصولين لأجل التشخيص والاختبار.
LIGATURE_PF_TO_BASE = {k: v for k, v in DEFERRED_PF_TO_BASE.items() if len(v) > 1}
SPACING_MARK_PF_TO_BASE = {k: v for k, v in DEFERRED_PF_TO_BASE.items() if len(v) == 1}


def unicode_version() -> str:
    """نسخة قاعدة بيانات يونيكود التي بُنيت منها الجداول (للتقارير)."""
    py = f"{sys.version_info.major}.{sys.version_info.minor}"
    return f"{unicodedata.unidata_version} (python {py})"
